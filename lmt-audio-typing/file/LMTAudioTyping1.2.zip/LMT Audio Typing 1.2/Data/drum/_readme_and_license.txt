Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by Veiler ( http://www.freesound.org/people/Veiler/  )
You can find this pack online at: http://www.freesound.org/people/Veiler/packs/16053/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 261413__veiler__crash.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261413/
    * license: Creative Commons 0
  * 261412__veiler__tom-2.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261412/
    * license: Creative Commons 0
  * 261411__veiler__tom-3.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261411/
    * license: Creative Commons 0
  * 261410__veiler__tom-4.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261410/
    * license: Creative Commons 0
  * 261409__veiler__kick-bass-win.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261409/
    * license: Creative Commons 0
  * 261408__veiler__snare-3.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261408/
    * license: Creative Commons 0
  * 261407__veiler__tom-1.wav
    * url: http://www.freesound.org/people/Veiler/sounds/261407/
    * license: Creative Commons 0

