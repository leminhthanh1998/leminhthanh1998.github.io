LMT Audio Typing ho tro ban de dang tao cac hieu ung am thanh khi an ban phim!
Website: http://l�minhth�nh.vn/lmt-audio-typing
----------------------------------
Ho tro cac dinh dang file: WAV, MP3, AIFF
----------------------------------
Changelog:
1.1:
-Sua loi khi doc file settings.
-Sua loi phat am thanh khi an 1 phim trong thoi gian lau.
-Sua loi khi phat am thanh.
1.2:
-Thay doi giao dien, chinh kich thuoc combobox hieu ung.
-Bo sung tinh nang thu am.
-Bo sung tuy chon khoi dong cung he thong.