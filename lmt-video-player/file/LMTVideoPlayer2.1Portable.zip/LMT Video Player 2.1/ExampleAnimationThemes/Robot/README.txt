A Pen created at CodePen.io. You can find this one at https://codepen.io/leminhthanh1998/pen/BPGxmb.

 It appeared that the robots were dancing in perfect synchronous harmony. That is, until something unexplained happened and drove them to break apart.