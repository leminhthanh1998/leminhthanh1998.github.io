A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/LVyJXw.

 A paranoid bird surrounded by two shy buddies with shifty look. A webgl experiment, using threejs and a little bit of TweenMax