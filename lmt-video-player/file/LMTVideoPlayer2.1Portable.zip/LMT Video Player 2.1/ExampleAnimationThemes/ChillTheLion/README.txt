A Pen created at CodePen.io. You can find this one at https://codepen.io/Yakudoo/pen/YXxmYR.

 WebGL experiment using ThreeJS. Move the fan and press to make wind, the lion will surely appreciate.